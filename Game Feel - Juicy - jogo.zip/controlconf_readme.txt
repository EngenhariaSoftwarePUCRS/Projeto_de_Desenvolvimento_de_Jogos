CONTROL CONFERENCE PRESENTATION ON """""GAME FEEL"""""
by Jan Willem Nijman


FIRST PART CONTROLS:
left/right arrow keys to move through slides
R to restart

SECOND PART CONTROLS:
left/right arrow keys to move
up/Z to jump
X to fire
R to restart
D for next trick
A for previous trick
S for current trick
P to pause


HAVE A GOOD EDUCATION